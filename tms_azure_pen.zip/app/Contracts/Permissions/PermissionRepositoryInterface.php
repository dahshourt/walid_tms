<?php
namespace App\Contracts\Permissions;

interface PermissionRepositoryInterface
{

	public function getAll();


}
