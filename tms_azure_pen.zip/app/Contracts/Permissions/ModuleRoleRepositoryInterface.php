<?php
namespace App\Contracts\Permissions;

interface ModuleRoleRepositoryInterface
{

	public function getAll();

    






}
