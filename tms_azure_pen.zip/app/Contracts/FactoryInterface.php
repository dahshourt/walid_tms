<?php

namespace App\Contracts;

interface FactoryInterface
{
	static public function index();
}